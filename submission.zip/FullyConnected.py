import numpy as np
from Layers.Base import *
from Optimization.Optimizers import *
class FullyConnected(BaseLayer):
    def __init__(self, input_size, output_size):
        super().__init__()
        self.input_size=input_size
        self.output_size=output_size
        self.weights = np.random.uniform(size=(input_size+1, output_size))
        self.biases = np.random.rand(1, output_size)
        self.trainable=True
        self._optimizer=None
        self.gradient_tensor=None
   
    @property
    def optimizer(self):
        return self._optimizer
    
    @optimizer.setter
    def optimizer(self, sett):
        self._optimizer = sett
    
    
    #Forward Pass
    def forward(self, input_tensor):
               
        self.input_tensor = np.concatenate((input_tensor, np.ones((input_tensor.shape[0], 1))), axis=1)
        #self.input_tensor=input_tensor

        # Calculate output values from inputs, weights and biases
        self.output = np.dot(self.input_tensor, self.weights) + self.biases
        return self.output
    
    
    # Backward pass
    def backward(self, error_tensor):
        # Gradients on parameters
        self.error_tensor=np.dot(error_tensor,self.weights[:-1, :].T)
        #self.error_tensor=np.dot(error_tensor,self.weights.T)
        self._gradient_tensor=np.dot(self.input_tensor.T,error_tensor)
        #gradient on values
        self.dinputs=np.dot(error_tensor,self.weights[:-1, :].T)
        #self.dinputs=np.dot(error_tensor,self.weights.T)
        
        if self.optimizer is not None:
            self.weights = self.optimizer.calculate_update(self.weights, self._gradient_tensor)
            self.biases = self.optimizer.calculate_update(self.biases, np.mean(error_tensor, axis=0, keepdims=True))
        return self.error_tensor
    
    @property
    def gradient_weights(self):
        
        return self._gradient_tensor

